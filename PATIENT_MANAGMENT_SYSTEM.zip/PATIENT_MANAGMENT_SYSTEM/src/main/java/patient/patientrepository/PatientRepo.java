package patient.patientrepository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import patient.domain.PatientEnt;

public interface PatientRepo extends JpaRepository<PatientEnt,Integer> {
	
	//@Query("SELECT pa FROM PatientEnt pa WHERE pa.status='Active'")
	//List<PatientEnt> findActivePatients();
	
	//@Query("SELECT pa FROM PatientEnt pa WHERE pa.status='Inactive'")
	//List<PatientEnt> findInactivePatients();

	List<PatientEnt> findByStatus(String status);
}
