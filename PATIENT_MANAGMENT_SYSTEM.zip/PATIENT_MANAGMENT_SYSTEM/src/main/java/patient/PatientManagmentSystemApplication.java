package patient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PatientManagmentSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(PatientManagmentSystemApplication.class, args);
	}

}
