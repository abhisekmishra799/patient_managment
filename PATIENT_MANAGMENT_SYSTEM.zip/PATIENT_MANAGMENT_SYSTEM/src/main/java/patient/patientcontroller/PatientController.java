package patient.patientcontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import patient.domain.PatientEnt;
import patient.patientservice.PatientService;

@Controller
public class PatientController {
	
	
	public PatientController()
	{
		System.out.println("inside patient controller");
	}
	
	
	
	@Autowired
	private PatientService service;
	
	@GetMapping("/")
	public String welcome()
	{
		return "registation";
	}
	
	@PostMapping("/insert")
	public String registerPatient(@ModelAttribute PatientEnt patient)
	{
		service.addPatient(patient);
		return "redirect:show";
	}
	
	@GetMapping("/show")
	public String showallpatient(Model model)
	{
		List<PatientEnt> list=service.showPatient();
		
		model.addAttribute("msg", list);
		return "patienttable";
	}
	
	
	@GetMapping("/upd")
	public String updatePatient(@RequestParam("id") Integer id,Model model)
	{
		PatientEnt list=service.getonepatient(id);
		model.addAttribute("msg", list);
		return "updatepatient";
	}
	
	@PostMapping("/update")
	public String updatePatient(@ModelAttribute PatientEnt patient)
	{
		service.updatePatient(patient);
		return "redirect:show";
	}
	
	@GetMapping("/delete")
	public String removePatient(@RequestParam("id") Integer id)
	{
		service.removePatient(id);
		return "redirect:show";
	}
	
	@PostMapping("/changestatus")
	public String checkstatusPatient(@RequestParam("id") Integer id)
	{
		service.checkStatus(id);
		return "redirect:show";
	}
	@GetMapping("/activePatient")
	public String getactivePatients(Model model)
	{
		List<PatientEnt> plist=service.getActivePatient();
		model.addAttribute("item", plist);
		
		return "patientbystatus";
	}
	@GetMapping("/inactivePatient")
	public String getinactivePatients(Model model)
	{
		List<PatientEnt> plist=service.getInActivePatient();
		model.addAttribute("item", plist);
		return "patientbystatus";
	}
}
