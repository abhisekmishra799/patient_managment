package patient.patientservice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import patient.domain.PatientEnt;
import patient.patientrepository.PatientRepo;
@Service
public class PatientImpl implements PatientService {
	
	@Autowired
	private PatientRepo repository;

	@Override
	public void addPatient(PatientEnt p) {
		repository.save(p);
	}

	@Override
	public void removePatient(Integer id) {
		repository.deleteById(id);
	}

	@Override
	public void updatePatient(PatientEnt p) {
		repository.save(p);
	}

	@Override
	public List<PatientEnt> showPatient() {
		List<PatientEnt> list=repository.findAll();
		return list;
	}

	@Override
	public PatientEnt getonepatient(Integer id) {
		PatientEnt ps=repository.findById(id).get();
		return ps;
	}
	public PatientEnt checkStatus(Integer id)
	{
		PatientEnt patient=repository.findById(id).get();
		if(patient == null)
		{
			return null;
		}
		if("Active".equals(patient.getStatus()))
		{
			patient.setStatus("Inactive");
		}
		else {
			patient.setStatus("Active");
		}
		return repository.save(patient);
	}
	
	public List<PatientEnt> getActivePatient()
	{
		return repository.findByStatus("Active");
	}
	public List<PatientEnt> getInActivePatient()
	{
		return repository.findByStatus("Inactive");
	}
}
