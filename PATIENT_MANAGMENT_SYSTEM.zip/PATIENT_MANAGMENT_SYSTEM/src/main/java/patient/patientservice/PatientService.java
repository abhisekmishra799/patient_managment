package patient.patientservice;

import java.util.List;

import patient.domain.PatientEnt;

public interface PatientService {

	public void addPatient(PatientEnt p);
	public void removePatient(Integer id);
	public void updatePatient(PatientEnt p);
	public  List<PatientEnt> showPatient();
	public PatientEnt getonepatient(Integer id);
	public PatientEnt checkStatus(Integer id);
	public List<PatientEnt> getActivePatient();
	public List<PatientEnt> getInActivePatient();
	
}
